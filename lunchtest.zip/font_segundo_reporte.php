<?php 
    
    require('header.php');

?>
<div class="container">
      <table>
        <thead>
          <tr>
              <th>Platillo  </th>
              <th>Test</th> <!-- Atraccion segun el id de la tabla platillo -->
              <th>Porciones:  </th>
              <th>000</th> <!-- Atraccion segun el id de la tabla platillo -->
              <th>Tiempo de preparacion</th>
              <th>000</th> <!-- Atraccion segun el id de la tabla platillo -->
              <th>No. Revicion</th>
              <th>000</th>
          </tr>
        </thead>
</table>
<hr/>
      <table>
        <thead>
          <tr>
              <th>Clave</th>
              <th>Ingrediente</th>
              <th>Unidad</th>
              <th>Cantidad bruta</th>
              <th>Merma</th>
              <th>Cantidad Neta</th>
              <th>Coste bruto</th>
              <th>Coste neto</th>
              <th>pax (%)</th>
              <th>pax ($)</th>
              
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>00test</td>
            <td>Test</td>
            <td>Kg</td>
            <td>5</td>
            <td>1</td>
            <td>5</td>
            <td>25</td>
            <td>25</td>
            <td>0.7</td>
            <td>6.5 %</td>
          </tr>
        </tbody>
      </table>
    
</div>